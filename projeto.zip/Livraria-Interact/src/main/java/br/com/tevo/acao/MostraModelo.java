package br.com.tevo.acao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.tevo.conexao.ConnectionFactory;
import br.com.tevo.modelo.Livro;
import br.com.tevo.modelo.Usuario;

@WebServlet("/MostraModelo")
public class MostraModelo extends HttpServlet {
	
	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		String paramId = request.getParameter("id");
		Integer id = Integer.valueOf(paramId);
		String acao = request.getParameter("acao");
		
		if(acao.equals("usuario")) {
			try {
				Connection con = new ConnectionFactory().getConnection();
				PreparedStatement ps = con.prepareStatement("SELECT ID, NOME, SENHA, EMAIL FROM USUARIOS WHERE ID = ?");
				ps.setInt(1, id);
				ResultSet rst = ps.executeQuery();

				while (rst.next()) {
					Usuario usuario = new Usuario();
					usuario.setNome(rst.getString("NOME"));
					usuario.setSenha(rst.getString("SENHA"));
					usuario.setEmail(rst.getString("EMAIL"));
					usuario.setId(rst.getInt("ID"));
					request.setAttribute("usuario", usuario);

				}
				RequestDispatcher dispatcher = request.getRequestDispatcher("/AlteraUsuario.jsp");
				dispatcher.forward(request, response);

			} catch (Exception e) {
				System.out.println("An error occurred: " + e.getMessage());
			}
			
		}if(acao.equals("livro")) {

			try {
				Connection con = new ConnectionFactory().getConnection();
				PreparedStatement ps = con.prepareStatement("SELECT ID, NOME, AUTOR, STATE FROM LIVROS WHERE ID = ?");
				ps.setInt(1, id);
				ResultSet rst = ps.executeQuery();

				while (rst.next()) {
					Livro livro = new Livro();
					livro.setNome(rst.getString("NOME"));
					livro.setAutor(rst.getString("AUTOR"));
					livro.setId(rst.getInt("ID"));
					request.setAttribute("livro", livro);

				}
				RequestDispatcher dispatcher = request.getRequestDispatcher("/AlteraLivro.jsp");
				dispatcher.forward(request, response);

			} catch (Exception e) {
				System.out.println("An error occurred: " + e.getMessage());
			}
		}
	}
	
}
