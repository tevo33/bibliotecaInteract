package br.com.tevo.conexao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ConnectionFactory {

	private static final String DATABASE_DRIVER = "com.mysql.cj.jdbc.Driver";
	private static final String DATABASE_URL = "jdbc:mysql://localhost:3306/livraria?useTimezone=true&serverTimezone=UTC";
	private static final String USERNAME = "root";
	private static final String PASSWORD = "1235";

	public Connection getConnection() throws Exception {

		Class.forName(DATABASE_DRIVER);
		return DriverManager.getConnection(DATABASE_URL, USERNAME, PASSWORD);
	}

	public static void closeConnection(Connection con) throws Exception {
		if (con != null) {
			con.close();
		}
	}

	public static void closeConnection(Connection con, PreparedStatement ps) throws Exception {
		closeConnection(con);
		if (ps != null) {
			ps.close();
		}
	}
	
	public static void closeConnection(Connection con, PreparedStatement ps, ResultSet rs) throws Exception {
		closeConnection(con, ps);
		if (rs != null) {
			rs.close();
		}
	}
	
}
