package br.com.tevo.consulta;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import br.com.tevo.acao.ListaUsuarios;
import br.com.tevo.conexao.ConnectionFactory;
import br.com.tevo.modelo.Usuario;

public class ControladorDeUsuario {

	public static List<Usuario> listaDeUsuarios = new ArrayList<>();

	public Usuario pegaUsuarioPeloLogin(String nome) {

		try {
			Connection con = new ConnectionFactory().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT ID, NOME, SENHA, EMAIL FROM USUARIOS WHERE NOME = ?");
			ps.setString(1, nome);
			ps.execute();

			try (ResultSet rs = ps.getResultSet()) {

				if (rs.next()) {
					Usuario usuario = new Usuario();
					usuario.setId(rs.getInt(1));
					usuario.setSenha(rs.getString(2));
					usuario.setSenha(rs.getString(3));
					usuario.setEmail(rs.getString(4));
					return usuario;
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return null;

	}

	public boolean verificar(String nome, String senha) {
		try {
			Connection con = new ConnectionFactory().getConnection();
			PreparedStatement ps = con
					.prepareStatement("SELECT NOME, SENHA FROM USUARIOS WHERE NOME = ? AND SENHA = ?");
			ps.setString(1, nome);
			ps.setString(2, senha);
			ps.execute();

			try (ResultSet rs = ps.getResultSet()) {

				if (rs.next()) {
					return true;
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return false;
	}

	public void alteraUsuario(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		String acao = request.getParameter("acao");
		String nome = request.getParameter("nome");
		String senha = request.getParameter("senha");
		String email = request.getParameter("email");

		String paramId = request.getParameter("id");
		Integer id = Integer.valueOf(paramId);

		if (acao.equals("edita")) {

			List<Usuario> usuarios = ListaUsuarios.listaDeUsuarios;

			Iterator<Usuario> it = usuarios.iterator();

			while (it.hasNext()) {
				Usuario usuario = it.next();
				if (usuario.getId() == id) {
					usuario.setNome(nome);
					usuario.setSenha(senha);
					usuario.setEmail(email);
				}
			}

			try {
				Connection con = new ConnectionFactory().getConnection();
				PreparedStatement ps = con
						.prepareStatement("UPDATE USUARIOS SET NOME = ?, SENHA = ?, EMAIL = ? WHERE id = ?");
				ps.setString(1, nome);
				ps.setString(2, senha);
				ps.setString(3, email);
				ps.setInt(4, id);
				int i = ps.executeUpdate();

				if (i > 0) {
					response.sendRedirect("/Livraria-Interact/ListaUsuarios");
				} else {
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.println("Não foi possível alterar o usuário");
				}

			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}

	public void listaUsuarios(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		try {
			listaDeUsuarios.clear();

			Connection con = new ConnectionFactory().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT ID, NOME, SENHA, EMAIL FROM USUARIOS\r\n" + "");
			ResultSet rst = ps.executeQuery();

			while (rst.next()) {
				Usuario usuario = new Usuario();
				usuario.setId(rst.getInt("ID"));
				usuario.setNome(rst.getString("NOME"));
				usuario.setSenha(rst.getString("SENHA"));
				usuario.setEmail(rst.getString("EMAIL"));
				listaDeUsuarios.add(usuario);
			}

			request.setAttribute("listaUsuarios", listaDeUsuarios);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/ListaUsuarios.jsp");
			dispatcher.forward(request, response);

		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
		}

	}

	public void Logar(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		response.setContentType("text/html");
		String nome = request.getParameter("nome");
		String senha = request.getParameter("senha");

		ControladorDeUsuario consulta = new ControladorDeUsuario();

		boolean usuarioExiste = consulta.verificar(nome, senha);

		if (usuarioExiste) {
			HttpSession sessao = request.getSession();
			Usuario usuario = consulta.pegaUsuarioPeloLogin(nome);
			sessao.setAttribute("idUsuario", usuario.getId());
			response.sendRedirect("/Livraria-Interact/PaginaDeFuncoes.jsp");
		} else {
			response.sendRedirect("/Livraria-Interact/Logar.jsp");
		}
	}

	public void Logout(ServletRequest servletRequest, ServletResponse servletResponse) throws IOException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		HttpSession sessao = request.getSession();
		sessao.removeAttribute("idUsuario");
		sessao.invalidate();
		response.sendRedirect("/Livraria-Interact/Logar.jsp");
	}

	public void registraUsuario(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		response.setContentType("text/html");

		String nome = request.getParameter("nome");
		String senha = request.getParameter("senha");
		String email = request.getParameter("email");

		try {
			Connection con = new ConnectionFactory().getConnection();

			PreparedStatement ps = con.prepareStatement("INSERT INTO USUARIOS (NOME, SENHA, EMAIL) VALUES (?, ?, ?)");
			ps.setString(1, nome);
			ps.setString(2, senha);
			ps.setString(3, email);
			int i = ps.executeUpdate();

			if (i > 0) {
				response.sendRedirect("/Livraria-Interact/ListaUsuarios");
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void removeUsuario(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		String acao = request.getParameter("acao");

		if (acao.equals("remove")) {
			String paramId = request.getParameter("id");
			Integer id = Integer.valueOf(paramId);

			List<Usuario> usuarios = ListaUsuarios.listaDeUsuarios;

			Iterator<Usuario> it = usuarios.iterator();

			while (it.hasNext()) {
				Usuario usuario = it.next();
				if (usuario.getId() == id) {
					it.remove();
					break;
				}
			}

			try {
				Connection con = new ConnectionFactory().getConnection();
				PreparedStatement ps = con.prepareStatement("DELETE FROM USUARIOS WHERE id = ?");
				ps.setInt(1, id);
				int i = ps.executeUpdate();

				if (i > 0) {
					response.sendRedirect("/Livraria-Interact/ListaUsuarios");
				} else {
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.println("Não foi possível remover o usuario");
				}

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}
}
