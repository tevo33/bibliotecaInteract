package br.com.tevo.acao;

import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import br.com.tevo.consulta.ControladorDeLivro;

@WebServlet("/DevolveRetiraLivro")
public class DevolveRetiraLivro extends HttpServlet {

	private static final long serialVersionUID = 1L;

	public void service(ServletRequest servletRequest, ServletResponse servletResponse) {
		 ControladorDeLivro controlador = new ControladorDeLivro();
	     controlador.devolveRetiraLivro(servletRequest, servletResponse);
	 }
	
}
