package br.com.tevo.acao;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.tevo.consulta.ControladorDeLivro;
import br.com.tevo.modelo.Livro;

@WebServlet("/ListaLivros")
public class ListaLivros extends HttpServlet {

	public static List<Livro> listaDeLivros = new ArrayList<Livro>();

	private static final long serialVersionUID = 1L;

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		 ControladorDeLivro controlador = new ControladorDeLivro();
		 controlador.listaLivros(request, response);
		 
	}

}
