package br.com.tevo.consulta;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.tevo.acao.ListaLivros;
import br.com.tevo.conexao.ConnectionFactory;
import br.com.tevo.modelo.Livro;

public class ControladorDeLivro {

	public static List<Livro> listaDeLivros = new ArrayList<Livro>();

	public Livro pegaLivroPeloId(int id) {

		try {
			Connection con = new ConnectionFactory().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT ID, NOME, AUTOR, STATE FROM LIVROS WHERE ID = ?");
			ps.setInt(1, id);
			ps.execute();

			try (ResultSet rs = ps.getResultSet()) {

				if (rs.next()) {
					Livro livro = new Livro();
					livro.setId(rs.getInt(1));
					livro.setNome(rs.getString(2));
					livro.setAutor(rs.getString(3));
					livro.setState(rs.getInt(4));
					return livro;
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return null;
	}

	public Livro pegaLivroPeloState(int state) {

		try {
			Connection con = new ConnectionFactory().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT ID, NOME, AUTOR, STATE FROM LIVROS WHERE state = ?");
			ps.setInt(1, state);
			ps.execute();

			try (ResultSet rs = ps.getResultSet()) {

				if (rs.next()) {
					Livro livro = new Livro();
					livro.setId(rs.getInt(1));
					livro.setNome(rs.getString(2));
					livro.setAutor(rs.getString(3));
					livro.setState(rs.getInt(4));
					return livro;
				}
			}
		} catch (Exception e) {
			System.out.println(e);
		}

		return null;

	}

	public void devolveRetiraLivro(ServletRequest servletRequest, ServletResponse servletResponse) {

		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		String acao = request.getParameter("acao");

		if (acao.equals("retira")) {
			String paramId = request.getParameter("id");
			Integer id = Integer.valueOf(paramId);
			List<Livro> livros = ListaLivros.listaDeLivros;

			Iterator<Livro> it = livros.iterator();

			while (it.hasNext()) {
				Livro livro = it.next();
				if (livro.getId() == id) {
					livro.setState(1);

				}
			}

			List<Livro> livros1 = ListaLivros.listaDeLivros;
			ControladorDeLivro cl = new ControladorDeLivro();
			Livro livro = cl.pegaLivroPeloId(id);
			livros1.add(livro);
			String nome = livro.getNome();
			String autor = livro.getAutor();

			try {
				Connection con = new ConnectionFactory().getConnection();
				PreparedStatement ps = con.prepareStatement("UPDATE LIVROS SET STATE = 1 WHERE id = ?");
				ps.setInt(1, id);
				int i = ps.executeUpdate();

				PreparedStatement pst = con.prepareStatement("INSERT INTO LIVROSRESERVADOS (NOME, AUTOR) VALUES(?, ?)");
				pst.setString(1, nome);
				pst.setString(2, autor);
				int e = pst.executeUpdate();

				if (i > 0 & e > 0) {
					response.sendRedirect("/Livraria-Interact/ListaLivros");
				} else {
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.println("Não foi possível alterar o livro");
				}

			} catch (Exception e) {
				System.out.println(e);
			}
		} else if (acao.equals("devolve")) {
			String paramId = request.getParameter("id");
			Integer id = Integer.valueOf(paramId);
			List<Livro> livros = ListaLivros.listaDeLivros;

			Iterator<Livro> it = livros.iterator();

			while (it.hasNext()) {
				Livro livro = it.next();
				if (livro.getId() == id) {
					livro.setState(0);
				}
			}

			List<Livro> livros1 = ListaLivros.listaDeLivros;
			ControladorDeLivro cl = new ControladorDeLivro();
			Livro livro = cl.pegaLivroPeloId(id);
			livros1.remove(livro);
			String nome = livro.getNome();

			try {
				Connection con = new ConnectionFactory().getConnection();
				PreparedStatement ps = con.prepareStatement("UPDATE LIVROS SET STATE = 0 WHERE id = ?");
				ps.setInt(1, id);
				int i = ps.executeUpdate();

				PreparedStatement pst = con.prepareStatement("DELETE FROM LIVROSRESERVADOS WHERE nome = ?");
				pst.setString(1, nome);
				int e = pst.executeUpdate();

				if (i > 0 & e > 0) {
					response.sendRedirect("/Livraria-Interact/ListaLivros");
				} else {
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.println("Não foi possível devolver o livro");
				}
			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	public void alteraLivro(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		String acao = request.getParameter("acao");

		String nome = request.getParameter("nome");

		String autor = request.getParameter("autor");

		String paramId = request.getParameter("id");
		Integer id = Integer.valueOf(paramId);

		if (acao.equals("edita")) {

			List<Livro> livros = ListaLivros.listaDeLivros;

			Iterator<Livro> it = livros.iterator();

			while (it.hasNext()) {
				Livro livro = it.next();
				if (livro.getId() == id) {
					livro.setAutor(autor);
					livro.setNome(nome);
				}
			}

			try {
				Connection con = new ConnectionFactory().getConnection();
				PreparedStatement ps = con.prepareStatement("UPDATE LIVROS SET NOME = ?, AUTOR = ? WHERE id = ?");
				ps.setString(1, nome);
				ps.setString(2, autor);
				ps.setInt(3, id);
				int i = ps.executeUpdate();

				if (i > 0) {
					response.sendRedirect("/Livraria-Interact/ListaLivros");
				} else {
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.println("Não foi possível alterar o livro");
				}

			} catch (Exception e) {
				System.out.println(e);
			}
		}
	}

	public void listaLivrosRetirados(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		List<Livro> listaDeLivros = new ArrayList<Livro>();

		try {
			listaDeLivros.clear();

			Connection con = new ConnectionFactory().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT ID, NOME, AUTOR FROM LIVROS WHERE STATE = 1");
			ResultSet rst = ps.executeQuery();

			while (rst.next()) {
				Livro livro = new Livro();
				livro.setNome(rst.getString("NOME"));
				livro.setAutor(rst.getString("AUTOR"));
				listaDeLivros.add(livro);
			}

			request.setAttribute("listaLivrosReservados", listaDeLivros);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/ListaLivrosReservados.jsp");
			dispatcher.forward(request, response);

		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
		}
	}

	public void listaLivros(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		try {
			listaDeLivros.clear();

			Connection con = new ConnectionFactory().getConnection();
			PreparedStatement ps = con.prepareStatement("SELECT ID, NOME, AUTOR, STATE FROM LIVROS\r\n" + "");
			ResultSet rst = ps.executeQuery();

			while (rst.next()) {
				Livro livro = new Livro();
				livro.setId(rst.getInt("ID"));
				livro.setNome(rst.getString("NOME"));
				livro.setAutor(rst.getString("AUTOR"));
				livro.setState(rst.getInt("STATE"));
				listaDeLivros.add(livro);
			}

			request.setAttribute("listaLivros", listaDeLivros);
			RequestDispatcher dispatcher = request.getRequestDispatcher("/ListaLivros.jsp");
			dispatcher.forward(request, response);

		} catch (Exception e) {
			System.out.println("An error occurred: " + e.getMessage());
		}

	}

	public void registraLivro(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		response.setContentType("text/html");
		String nome = request.getParameter("nome");
		String autor = request.getParameter("autor");

		Integer state = Livro.STATE_DISPONÍVEL;

		try {
			Connection con = new ConnectionFactory().getConnection();

			PreparedStatement ps = con.prepareStatement("INSERT INTO LIVROS (NOME, AUTOR, STATE) VALUES (?, ?, ?)");
			ps.setString(1, nome);
			ps.setString(2, autor);
			ps.setInt(3, state);

			int i = ps.executeUpdate();

			if (i > 0) {
				response.sendRedirect("/Livraria-Interact/ListaLivros");
			}

		} catch (Exception e) {
			System.out.println(e);
		}

	}

	public void removeLivro(ServletRequest servletRequest, ServletResponse servletResponse) {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		String acao = request.getParameter("acao");

		if (acao.equals("remove")) {
			String paramId = request.getParameter("id");
			Integer id = Integer.valueOf(paramId);

			List<Livro> livros = ListaLivros.listaDeLivros;

			Iterator<Livro> it = livros.iterator();

			while (it.hasNext()) {
				Livro livro = it.next();
				if (livro.getId() == id) {
					it.remove();
					break;
				}
			}

			try {
				Connection con = new ConnectionFactory().getConnection();
				PreparedStatement ps = con.prepareStatement("DELETE FROM LIVROS WHERE id = ?");
				ps.setInt(1, id);
				int i = ps.executeUpdate();

				if (i > 0) {
					response.sendRedirect("/Livraria-Interact/ListaLivros");
				} else {
					response.setContentType("text/html");
					PrintWriter out = response.getWriter();
					out.println("Não foi possível remover o livro");
				}

			} catch (Exception e) {
				System.out.println(e);
			}
		}

	}


}
