package br.com.tevo.acao;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class Autorizacao {

	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		String paramAcao = request.getParameter("acao");
		HttpSession sessao = request.getSession();
		sessao.setAttribute("acao", paramAcao);
		
		
		
	}
}
